from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

def init_db():
    conn = sqlite3.connect('finance.db')
    c = conn.cursor()
    
    c.execute('''CREATE TABLE IF NOT EXISTS income
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  amount REAL NOT NULL,
                  source TEXT NOT NULL,
                  date TEXT NOT NULL,
                  description TEXT)''')
                  
    c.execute('''CREATE TABLE IF NOT EXISTS expenses
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  amount REAL NOT NULL,
                  category TEXT NOT NULL,
                  date TEXT NOT NULL,
                  description TEXT)''')
    
    conn.commit()
    conn.close()

@app.route('/')
def index():
    balance = get_balance()
    
    conn = sqlite3.connect('finance.db')
    c = conn.cursor()
    
    c.execute("SELECT * FROM income ORDER BY date DESC LIMIT 5")
    incomes = c.fetchall()
    
    c.execute("SELECT * FROM expenses ORDER BY date DESC LIMIT 5")
    expenses = c.fetchall()
    
    conn.close()
    
    return render_template('index.html', 
                         balance=balance,
                         incomes=incomes,
                         expenses=expenses)

@app.route('/add_income', methods=['GET', 'POST'])
def add_income():
    if request.method == 'POST':
        amount = float(request.form['amount'])
        source = request.form['source']
        description = request.form.get('description', '')
        date = request.form.get('date', datetime.now().strftime('%Y-%m-%d'))
        
        conn = sqlite3.connect('finance.db')
        c = conn.cursor()
        
        c.execute("INSERT INTO income (amount, source, date, description) VALUES (?, ?, ?, ?)",
                 (amount, source, date, description))
        
        conn.commit()
        conn.close()
        
        flash('Доход успешно добавлен!', 'success')
        return redirect(url_for('index'))
    
    return render_template('add_income.html', datetime=datetime)

@app.route('/add_expense', methods=['GET', 'POST'])
def add_expense():
    if request.method == 'POST':
        amount = float(request.form['amount'])
        category = request.form['category']
        description = request.form.get('description', '')
        date = request.form.get('date', datetime.now().strftime('%Y-%m-%d'))
        
        conn = sqlite3.connect('finance.db')
        c = conn.cursor()
        
        c.execute("INSERT INTO expenses (amount, category, date, description) VALUES (?, ?, ?, ?)",
                 (amount, category, date, description))
        
        conn.commit()
        conn.close()
        
        flash('Расход успешно добавлен!', 'success')
        return redirect(url_for('index'))
    
    return render_template('add_expense.html', datetime=datetime)

@app.route('/report')
def report():
    conn = sqlite3.connect('finance.db')
    c = conn.cursor()
    
    c.execute("SELECT SUM(amount) FROM income")
    total_income = c.fetchone()[0] or 0
    
    c.execute("SELECT SUM(amount) FROM expenses")
    total_expenses = c.fetchone()[0] or 0
    
    c.execute("SELECT source, SUM(amount) FROM income GROUP BY source")
    income_by_source = c.fetchall()
    
    c.execute("SELECT category, SUM(amount) FROM expenses GROUP BY category")
    expenses_by_category = c.fetchall()
    
    conn.close()
    
    return render_template('report.html',
                         total_income=total_income,
                         total_expenses=total_expenses,
                         income_by_source=income_by_source,
                         expenses_by_category=expenses_by_category)

def get_balance():
    conn = sqlite3.connect('finance.db')
    c = conn.cursor()
    
    c.execute("SELECT SUM(amount) FROM income")
    total_income = c.fetchone()[0] or 0
    
    c.execute("SELECT SUM(amount) FROM expenses")
    total_expenses = c.fetchone()[0] or 0
    
    conn.close()
    
    return total_income - total_expenses

if __name__ == '__main__':
    init_db()
    app.run(debug=True)